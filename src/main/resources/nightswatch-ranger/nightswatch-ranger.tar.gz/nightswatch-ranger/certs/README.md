Copy certificates and key files into `p1` directory when initialization.
Certificates can be created and downloaded from the AWS IoT Console.
Reference `Place certificate, public and private key files` section in the README.md file at root directory.
