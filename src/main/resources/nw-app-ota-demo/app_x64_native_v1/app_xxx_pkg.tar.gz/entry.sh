#!/bin/sh

echo "Start..."
/opt/nightswatch-ranger/apps/app_xxx/rootfs/entry 127.0.0.1 app_xxx /qbr/demo/lcd
