#!/bin/sh

echo "Start..."
entry 127.0.0.1 app_xxx /qbr/demo/lcd
